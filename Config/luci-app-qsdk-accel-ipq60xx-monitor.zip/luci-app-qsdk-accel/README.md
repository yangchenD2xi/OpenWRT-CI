# luci-app-qsdk-accel

`luci-app-qsdk-accel` is a small, defensive LuCI control panel for Qualcomm
QSDK acceleration stacks. It detects ECM and the compiled front ends (NSS,
PPE, SFE and SDX), shows live accelerated-flow counters, and exposes a limited
set of service and diagnostics operations.

The package deliberately does not depend on one particular acceleration
kernel package: Qualcomm SDK releases and community trees use different ECM
front ends and package names. Install the appropriate ECM/NSS/PPE modules for
the target firmware separately.

## Features

- Health summary with live IPv4/IPv6 accelerated, pending and ECM connection counters
- Detailed command latency, queue depth and ECM database counters
- Five-minute accelerated-flow and SUnreclaim trend charts kept only in the browser
- Read-only NSS performance telemetry with 5-second sampling and a 15-minute browser-only history
- Three-state telemetry reporting that distinguishes missing, readable-but-unparsed and parsed NSS statistics
- NSS/PPE/SFE/SDX capability detection
- NSS firmware, core, clock, packet-buffer, client-module and statistics discovery
- Capability-based IPQ50xx/older QSDK 5.4 support without model-specific checks
- NSS firmware boot-log detection and debugfs/devfreq clock fallbacks
- Optional ECM exception-counter path discovery and Wi-Fi NSS log/module detection
- ECM service start, stop and restart controls
- Safe ECM connection flush operation with confirmation
- Optional delayed ECM startup after the rest of the system has booted
- Capability-aware settings that never invent unavailable vendor ECM options
- Diagnostic report and downloadable text/JSON snapshots
- NSS core, driver, N2H, IPv4/IPv6 and Wi-Fi cumulative counters with per-second rates
- IPv4/IPv6 offload-exception ranking with count and share breakdowns
- One-click read-only health check with pass, warning and failure guidance
- Automatic BootstrapDark and generic dark-theme appearance detection
- Simplified Chinese and English UI strings

## Build

Place this directory under `feeds/luci/applications/luci-app-qsdk-accel`, then
select **LuCI → Applications → luci-app-qsdk-accel** in `make menuconfig`.

For a standalone package build:

```sh
./scripts/feeds update luci
./scripts/feeds install luci-app-qsdk-accel
make package/feeds/luci/luci-app-qsdk-accel/compile V=s
```

## GitHub Actions cloud build and release

The included `.github/workflows/build-apk.yml` uses
`sbwml/openwrt-gh-action-sdk` with ImmortalWrt SDK containers to build both:

- an IPK for ImmortalWrt 23.05 `qualcommax/ipq50xx_32`;
- an APK for ImmortalWrt 25.12 `qualcommax/ipq807x`.

It runs checks and builds on pushes to `main`, pull requests, version tags,
published Releases and manual dispatches. Ordinary runs keep the IPK and APK as
separate Actions artifacts.

For a formal release, use a tag that exactly matches `PKG_VERSION`, for example
`v0.5.2`. The release job waits for both matrix builds, places every generated
IPK and APK directly in the matching GitHub Release, and generates one
`SHA256SUMS` covering all uploaded package files. Re-running the workflow
updates same-name assets instead of creating a second Release.

The workflow stages only the package sources into an isolated temporary feed,
so local archives, build outputs and development tools cannot be discovered as
duplicate package definitions.

Executable permissions for the init, UCI-defaults and rpcd scripts are enforced
both while staging the CI feed and again from the package prepare hook. This
keeps APK metadata correct even when the source was checked out on Windows or
uploaded through a mechanism that does not preserve Unix file modes.

After installation, sign out of LuCI and sign in again if the menu entry is not
immediately visible. Open **Status → QSDK Acceleration**.

The same source builds an `.apk` on current APK-based OpenWrt/ImmortalWRT
snapshots and an `.ipk` on older opkg-based trees. The output format is selected
by the matching build system; no package-source changes are required.

## Performance telemetry

The **Performance** page requests a read-only telemetry snapshot every five
seconds and retains at most 180 samples (about 15 minutes) in the browser. It
shows NSS core load and clock information, ECM accelerated and pending flows,
and selected driver, N2H, IPv4/IPv6 and Wi-Fi counters. Rates are calculated
from the real interval between samples. A counter decrease resets that metric's
baseline, so a driver reload or counter wrap never appears as a negative rate.

No sampler daemon is installed and no history is written to `/tmp` or flash.
Closing or reloading the page clears the samples. Every telemetry source is
probed independently. Since v0.5.1, each NSS statistics capability reports
`available`, `parsed`, `counter_count` and `parser` separately:

- `available: false` means that no readable source was found.
- `available: true, parsed: false` means that the source exists, but this
  firmware's counter format was not recognized.
- `available: true, parsed: true` means that named integer counters were parsed;
  `counter_count` is the number returned in `counters` and `parser` is
  `named_integer`.

Missing and unrecognized optional statistics are informational capabilities,
not acceleration failures, and neither state is represented as a valid zero.
The Performance page normally selects RX/TX/drop/error counters. If parsed data
exists but none of its names match those semantic groups, it falls back to the
first 24 parsed vendor counters and labels the section as raw-counter
compatibility output. The fallback uses the same read-only `counters` array; it
does not evaluate or execute content from debugfs. The downloadable diagnostic
JSON includes one telemetry snapshot for offline comparison.

On resource-constrained IPQ5000 systems, each NSS source is bounded to the
first 1024 input lines and 32 returned counters. The page displays at most 24
per client, so this substantially reduces rpcd JSON assembly work without
changing the five-second summary sampling interval.

## Compatibility and safety

The read path checks for debugfs files before reading them. Legacy scalar
summary fields may retain zero defaults for compatibility, while telemetry
stats use explicit availability and parsing state. The write path accepts only
fixed actions and known ECM init script names. Delayed startup is disabled by
default, so installing this LuCI package does not change the device's existing
acceleration boot policy.

Older QSDK 5.4 builds, including IPQ50xx platforms, often omit newer NSS
sysctls, expose only one NSS core, or place ECM exception counters below a
front-end directory. The backend probes each capability independently. Missing
optional clock, second-core, Wi-Fi, or exception telemetry is therefore shown
as unavailable/informational instead of being treated as a device failure.

v0.5.2 also avoids conflating a readable NSS stats file with a successfully
parsed file. A source such as `/sys/kernel/debug/qca-nss-drv/stats/ipv4` may be
present while its vendor-specific layout is still unknown; in that case LuCI
reports that the source was detected but the counter format was not recognized.
The parser now covers the classified QSDK 12.5 form (`name = value common`,
`drop`, `error`, `special` or `exception`) and the three-column
`cpu_load_ubi` Min/Avg/Max percentage table observed on IPQ807x and both
collected IPQ5000 firmware lines, including QSDK 5.4. It also keeps
decorated N2H and vendor section headings in stable counter IDs. This remains a
strict, non-negative integer parser and never executes debugfs content.

Stopping or restarting ECM can briefly interrupt accelerated connections. The
UI always asks for confirmation before a state-changing action.

## Platform capability collection

When an older or uncommon QSDK build exposes different telemetry paths, copy
`tools/collect-ipq-platform-info.sh` to the router and run it as root:

```sh
chmod +x /tmp/collect-ipq-platform-info.sh
/tmp/collect-ipq-platform-info.sh > /tmp/ipq-platform-info.txt 2>&1
```

The collector is read-only and does not read UCI/network configuration or
credential files. It records device-tree/SoC identity, acceleration modules, NSS
sysctls, ECM/NSS debugfs paths, candidate clock and exception counters, and
the first 120 lines of the principal NSS telemetry files, plus relevant kernel
messages. MAC addresses in collected file content and kernel messages are
replaced with `[MAC]`; review the text file before sharing because other device
identifiers may still be present.

Sanitized captures retained in this repository live under
`platform-samples/`. Read its `README.md`, `index.json` and every sample
manifest before changing shared capability detection. Generic parser, schema,
health or UI changes must be compared against every registered platform sample
rather than being designed around one router.

## Result-correctness updates (v0.6 batch 1)

The current source checks the actual ECM flush write result and probes each NSS
clock value together with its source. A failed status refresh does not retry a
state-changing operation.

Exceptions now distinguish the exact scanned sum from the displayed top 40
reasons. Complete sources show a total; incomplete scans show a scanned sum,
and missing or unrecognized data is not presented as a valid zero. Exact
decimal strings preserve large counters. Legacy numeric fields remain for old
clients; the additional fields and read limits are documented in `design.md`
section 11. These changes do not declare v0.6 device validation complete.
