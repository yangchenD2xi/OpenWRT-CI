IPQ60XX QSDK 加速只读监控适配版
================================
基于用户上传的 wwng2333/luci-app-qsdk-accel 0.5.2 源码。
修改范围：RPC status 额外增加 Linux HW_OFFLOAD / OFFLOAD 统计、NSS Wi-Fi / PPE 检测；LuCI 概览改为只读监控；菜单只保留概览；ACL 不授予 ECM 控制权限。

将本目录作为 OpenWrt 软件包源目录 package/luci-app-qsdk-accel，配合
CONFIG_PACKAGE_luci-app-qsdk-accel=y 编译。

重要说明：
- HW_OFFLOAD 是 Linux 硬件卸载连接标记，并不等于 NSS 核心计数。
- NSS Wi-Fi 驱动启动、PPE 初始化、硬件卸载实际发生是三个独立信息。
- 缺少 /proc/net/nf_conntrack 时显示 N/A，不当成 0。
- 保留原项目其他源码，但 LuCI 菜单只提供只读概览，不提供 ECM 控制按钮。
- 没有经过用户实际设备的固件编译和运行验证。
