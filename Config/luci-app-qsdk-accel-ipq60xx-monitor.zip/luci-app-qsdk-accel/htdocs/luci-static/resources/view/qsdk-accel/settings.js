'use strict';
'require view';
'require form';
'require rpc';

var callStatus = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'status',
	expect: { '': {} }
});

function addStyle() {
	if (!document.querySelector('link[data-qsdk-accel]'))
		document.head.appendChild(E('link', {
			rel: 'stylesheet',
			href: L.resource('view/qsdk-accel/style.css'),
			'data-qsdk-accel': '1'
		}));
}

function isDarkTheme() {
	var media = String((L.env && L.env.media) || '').toLowerCase();
	var links = document.querySelectorAll('link[rel="stylesheet"]');
	var color, match, luminance;
	if (media.indexOf('bootstrap-dark') !== -1)
		return true;
	for (var i = 0; i < links.length; i++)
		if (String(links[i].href || '').toLowerCase().indexOf('/bootstrap-dark/') !== -1)
			return true;
	color = window.getComputedStyle(document.body).backgroundColor;
	match = color && color.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
	if (!match)
		return false;
	luminance = 0.2126 * +match[1] + 0.7152 * +match[2] + 0.0722 * +match[3];
	return luminance < 128;
}

return view.extend({
	load: function() {
		return Promise.all([ callStatus() ]);
	},

	render: function(result) {
		var m, s, o;
		var status = (result && result[0]) || {};
		addStyle();

		m = new form.Map('qsdk-accel', _('QSDK Acceleration Settings'),
			_('Configure the optional delayed-start manager. This does not install acceleration drivers or alter the vendor ECM service configuration.'));

		s = m.section(form.NamedSection, 'main', 'qsdk_accel', _('Startup management'));
		s.addremove = false;
		s.anonymous = true;

		o = s.option(form.Flag, 'enabled', _('Enable delayed ECM startup'));
		o.default = o.disabled;
		o.rmempty = false;
		o.description = _('Start the selected ECM service after this device has completed its normal boot sequence. Disabled by default to preserve the firmware vendor policy.');

		o = s.option(form.Value, 'startup_delay', _('Startup delay'));
		o.datatype = 'range(0,300)';
		o.default = '20';
		o.placeholder = '20';
		o.depends('enabled', '1');
		o.description = _('Seconds to wait before starting ECM (0–300). A short delay can prevent early-boot interface timing problems on some QSDK builds.');

		o = s.option(form.ListValue, 'ecm_service', _('ECM init service'));
		o.value('qca-nss-ecm', 'qca-nss-ecm');
		o.value('ecm', 'ecm');
		o.default = 'qca-nss-ecm';
		o.rmempty = false;
		o.description = _('Choose the init script provided by the installed QSDK acceleration package.');

		return m.render().then(function(formNode) {
			var notice = status.ecm_config_present
				? E('div', { 'class': 'qa-callout' }, [
					E('strong', {}, _('Vendor ECM configuration detected')),
					E('span', {}, _('This page intentionally leaves vendor-specific ECM parameters unchanged.'))
				])
				: E('div', { 'class': 'qa-callout' }, [
					E('strong', {}, _('No ECM UCI configuration was found')),
					E('span', {}, _('This firmware does not expose /etc/config/ecm. Only the delayed-start manager below is configurable; unsupported runtime switches are not shown.'))
				]);
			return E('div', {
				'class': 'qa-root ' + (isDarkTheme() ? 'qa-theme-dark' : 'qa-theme-light')
			}, [ notice, formNode ]);
		});
	}
});
