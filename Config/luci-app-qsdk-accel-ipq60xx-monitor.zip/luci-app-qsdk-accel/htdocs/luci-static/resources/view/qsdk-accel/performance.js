'use strict';
'require view';
'require rpc';
'require poll';
'require qsdk_accel.decimal as decimal';

var POLL_SECONDS = 5;
var MAX_SAMPLES = 180;
var MAX_COUNTERS_PER_CLIENT = 24;

var callTelemetry = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'telemetry',
	expect: { '': {} }
});

var clientOrder = [ 'drv', 'n2h', 'ipv4', 'ipv6', 'wifi', 'wifili', 'pppoe' ];
var clientNames = {
	drv: _('NSS driver'),
	n2h: _('NSS-to-host'),
	ipv4: _('NSS IPv4'),
	ipv6: _('NSS IPv6'),
	wifi: _('NSS Wi-Fi'),
	wifili: _('NSS Wi-FiLi'),
	pppoe: _('NSS PPPoE')
};

function addStyle() {
	if (!document.querySelector('link[data-qsdk-accel]'))
		document.head.appendChild(E('link', {
			rel: 'stylesheet',
			href: L.resource('view/qsdk-accel/style.css'),
			'data-qsdk-accel': '1'
		}));
}

function isDarkTheme() {
	var media = String((L.env && L.env.media) || '').toLowerCase();
	var links = document.querySelectorAll('link[rel="stylesheet"]');
	var color, match, luminance;
	if (media.indexOf('bootstrap-dark') !== -1)
		return true;
	for (var i = 0; i < links.length; i++)
		if (String(links[i].href || '').toLowerCase().indexOf('/bootstrap-dark/') !== -1)
			return true;
	color = window.getComputedStyle(document.body).backgroundColor;
	match = color && color.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
	if (!match)
		return false;
	luminance = 0.2126 * +match[1] + 0.7152 * +match[2] + 0.0722 * +match[3];
	return luminance < 128;
}

function rootClass() {
	return 'qa-root ' + (isDarkTheme() ? 'qa-theme-dark' : 'qa-theme-light');
}

function isAvailable(metric) {
	return !!(metric && metric.available);
}

function metricCounters(metric) {
	return metric && Array.isArray(metric.counters) ? metric.counters : [];
}

function isParsed(metric) {
	if (!isAvailable(metric))
		return false;
	if (metric.parsed !== null && metric.parsed !== undefined)
		return !!metric.parsed;
	return metricCounters(metric).length > 0;
}

function parsedCounterCount(metric) {
	var count = decimalText(metric && metric.counter_count);
	return count === null ? String(metricCounters(metric).length) : count;
}

var decimalText = decimal.decimalText;
var formatInteger = decimal.formatInteger;
var compareDecimal = decimal.compareDecimal;
var subtractDecimal = decimal.subtractDecimal;
var divideDecimal = decimal.divideDecimal;

function rateBetween(currentValue, previousValue, elapsed) {
	var currentText = decimalText(currentValue);
	var previousText = decimalText(previousValue);
	var current, previous, scaled, whole, fraction, difference, text;

	if (currentText === null || previousText === null || !elapsed || elapsed <= 0)
		return null;

	if (typeof BigInt === 'function') {
		try {
			current = BigInt(currentText);
			previous = BigInt(previousText);
			if (current < previous)
				return { reset: true };
			scaled = (current - previous) * BigInt(10) / BigInt(elapsed);
			whole = scaled / BigInt(10);
			fraction = scaled % BigInt(10);
			return {
				reset: false,
				text: formatInteger(whole.toString()) + (fraction ? '.' + fraction.toString() : '')
			};
		}
		catch (e) {
			/* Fall back for browsers that expose an unusable BigInt implementation. */
		}
	}

	if (compareDecimal(currentText, previousText) < 0)
		return { reset: true };
	difference = subtractDecimal(currentText, previousText);
	text = divideDecimal(difference, elapsed, 1);
	return text === null ? null : { reset: false, text: text.replace(/\.0$/, '') };
}

function counterKey(client, counter) {
	return client + ':' + String(counter.id || counter.group + '.' + counter.label);
}

function counterMap(data) {
	var result = {};
	var clients = (data && data.clients) || {};
	clientOrder.concat([ 'cpu_load_ubi' ]).forEach(function(client) {
		((clients[client] || {}).counters || []).forEach(function(counter) {
			if (decimalText(counter.value) !== null)
				result[counterKey(client, counter)] = String(counter.value);
		});
	});
	return result;
}

function loadPercent(data) {
	var load = (((data || {}).core || {}).load) || {};
	var counters = load.counters || [];
	var fallback = null;
	for (var i = 0; i < counters.length; i++) {
		var counter = counters[i];
		var name = [ counter.id, counter.group, counter.label ].join(' ');
		var value = Number(decimalText(counter.value));
		if (!/(^|[._\s-])(load|utilization|utilisation|usage)(?=$|[._\s-])/i.test(name) ||
			!isFinite(value) || value < 0 || value > 100)
			continue;
		if (/(^|[._\s-])(average|avg|current)(?=$|[._\s-])/i.test(name))
			return value;
		if (fallback === null)
			fallback = value;
	}
	return fallback;
}

function numericCounter(value) {
	var text = decimalText(value);
	var number = text === null ? NaN : Number(text);
	return isFinite(number) ? number : null;
}

function clockText(core) {
	var hz = numericCounter(core && core.clock_hz);
	if (hz === null || hz <= 0)
		return null;
	return (hz / 1000000).toFixed(hz % 1000000 ? 1 : 0) + ' MHz';
}

function sourceText(source) {
	return source && source !== 'unavailable'
		? _('Source: %s').format(source)
		: _('This firmware does not provide this metric.');
}

function parsedCountText(metric) {
	return _('Parsed counters: %s').format(formatInteger(parsedCounterCount(metric)) || '0');
}

function capabilityMeta(metric) {
	var source = sourceText(metric && metric.source);
	return isAvailable(metric) ? source + ' · ' + parsedCountText(metric) : source;
}

function capabilityEmptyText(metric, parsedEmptyText) {
	if (!isAvailable(metric))
		return _('This firmware does not provide this metric.');
	if (!isParsed(metric))
		return _('The source exists, but its counter format was not recognized.');
	return parsedEmptyText || _('No parsed counters were returned.');
}

function metricCard(label, value, meta, emptyText) {
	var unavailable = value === null || value === undefined;
	return E('div', { 'class': 'qa-card qa-performance-card' }, [
		E('div', { 'class': 'qa-label' }, label),
		E('div', { 'class': 'qa-value' + (unavailable ? ' qa-value-unavailable' : '') },
			unavailable ? (emptyText || _('This firmware does not provide this metric.')) : String(value)),
		E('div', { 'class': 'qa-meta qa-source' }, meta || '')
	]);
}

function chart(title, id, legend) {
	return E('div', { 'class': 'qa-card qa-chart-card' }, [
		E('div', { 'class': 'qa-chart-header' }, [
			E('div', { 'class': 'qa-label' }, title),
			E('div', { 'class': 'qa-chart-legend' }, legend)
		]),
		E('canvas', {
			'id': id,
			'class': 'qa-chart',
			'width': '640',
			'height': '180',
			'role': 'img',
			'aria-label': title
		}),
		E('div', { 'id': id + '-empty', 'class': 'qa-chart-empty' },
			_('This firmware does not provide this metric.'))
	]);
}

function setChartEmptyText(id, message) {
	var empty = document.getElementById(id + '-empty');
	if (empty)
		empty.textContent = message;
}

function drawChart(id, series, maxValue) {
	var canvas = document.getElementById(id);
	var empty = document.getElementById(id + '-empty');
	var hasValues = series.some(function(values) {
		return (values || []).some(function(value) { return value !== null && isFinite(value); });
	});
	if (!canvas)
		return;
	canvas.style.display = hasValues ? 'block' : 'none';
	if (empty)
		empty.style.display = hasValues ? 'none' : 'flex';
	if (!hasValues)
		return;

	var context = canvas.getContext('2d');
	if (!context)
		return;
	var rect = canvas.getBoundingClientRect();
	var width = Math.max(240, Math.round(rect.width || canvas.clientWidth || 320));
	var height = Math.max(100, Math.round(rect.height || canvas.clientHeight || 144));
	var ratio = Math.max(1, window.devicePixelRatio || 1);
	var root = canvas.closest('.qa-root') || document.documentElement;
	var style = window.getComputedStyle(root);
	var gridColor = style.getPropertyValue('--qa-chart-grid').trim() || '#607080';
	var textColor = style.getPropertyValue('--qa-meta').trim() || '#82909b';
	var colors = [
		style.getPropertyValue('--qa-chart-a').trim() || '#1686c9',
		style.getPropertyValue('--qa-chart-b').trim() || '#7357c6'
	];
	var padding = { left: 42, right: 8, top: 8, bottom: 18 };
	var plotWidth = width - padding.left - padding.right;
	var plotHeight = height - padding.top - padding.bottom;
	var ceiling = Math.max(+maxValue || 0, 1);

	if (canvas.width !== Math.round(width * ratio) || canvas.height !== Math.round(height * ratio)) {
		canvas.width = Math.round(width * ratio);
		canvas.height = Math.round(height * ratio);
	}
	context.setTransform(ratio, 0, 0, ratio, 0, 0);
	context.clearRect(0, 0, width, height);
	context.font = '10px sans-serif';
	context.textAlign = 'right';
	context.textBaseline = 'middle';
	context.fillStyle = textColor;
	context.strokeStyle = gridColor;
	context.lineWidth = 1;

	for (var grid = 0; grid <= 4; grid++) {
		var y = padding.top + plotHeight * grid / 4;
		context.globalAlpha = grid === 4 ? 0.8 : 0.35;
		context.beginPath();
		context.moveTo(padding.left, y + 0.5);
		context.lineTo(width - padding.right, y + 0.5);
		context.stroke();
		context.globalAlpha = 1;
		context.fillText(String(Math.round(ceiling * (4 - grid) / 4)), padding.left - 6, y);
	}

	series.forEach(function(values, seriesIndex) {
		var drawing = false;
		context.strokeStyle = colors[seriesIndex] || colors[0];
		context.fillStyle = context.strokeStyle;
		context.lineWidth = 2;
		context.lineCap = 'round';
		context.lineJoin = 'round';
		context.beginPath();
		(values || []).forEach(function(value, index) {
			if (value === null || !isFinite(value)) {
				if (drawing)
					context.stroke();
				drawing = false;
				context.beginPath();
				return;
			}
			var x = values.length === 1
				? padding.left + plotWidth
				: padding.left + index * plotWidth / (values.length - 1);
			var y = padding.top + plotHeight - Math.min(ceiling, Math.max(0, value)) / ceiling * plotHeight;
			if (!drawing) {
				context.moveTo(x, y);
				drawing = true;
			}
			else {
				context.lineTo(x, y);
			}
		});
		if (drawing)
			context.stroke();
	});
}

function counterPriority(counter) {
	var text = [ counter.id, counter.group, counter.label ].join(' ').toLowerCase();
	if (/(^|[._\s-])(rx|receive|received)(?=$|[._\s-])/.test(text))
		return 0;
	if (/(^|[._\s-])(tx|transmit|transmitted)(?=$|[._\s-])/.test(text))
		return 1;
	if (/(^|[._\s-])(drop|dropped|discard|discarded)(?=$|[._\s-])/.test(text))
		return 2;
	if (/(^|[._\s-])(error|errors|fail|failed|failure)(?=$|[._\s-])/.test(text))
		return 3;
	return -1;
}

function relevantCounters(client) {
	return metricCounters(client).map(function(counter, index) {
		return { counter: counter, index: index, priority: counterPriority(counter) };
	}).filter(function(item) {
		return item.priority >= 0 && decimalText(item.counter.value) !== null;
	}).sort(function(a, b) {
		return a.priority - b.priority || a.index - b.index;
	});
}

function parsedCounters(client) {
	return metricCounters(client).map(function(counter, index) {
		return { counter: counter, index: index, priority: counterPriority(counter) };
	}).filter(function(item) {
		return decimalText(item.counter.value) !== null;
	});
}

function clientCounterSelection(client) {
	var relevant = relevantCounters(client);
	return {
		entries: relevant.length ? relevant : parsedCounters(client),
		rawFallback: relevant.length === 0 && isParsed(client)
	};
}

function humanCounter(counter) {
	var label = String(counter.label || counter.id || _('Counter')).replace(/[_-]+/g, ' ');
	var group = String(counter.group || '').replace(/[_-]+/g, ' ');
	return group && label.toLowerCase().indexOf(group.toLowerCase()) !== 0
		? group + ' · ' + label
		: label;
}

function clientSection(name, client, rates) {
	client = client || {};
	var selection = clientCounterSelection(client);
	var entries = selection.entries;
	var visible = entries.slice(0, MAX_COUNTERS_PER_CLIENT);
	var rows = visible.map(function(entry) {
		var counter = entry.counter;
		var result = rates[counterKey(name, counter)];
		var rate = result && result.reset
			? _('Baseline reset')
			: result && result.text !== undefined
				? _('%s / second').format(result.text)
				: _('Waiting for next sample');
		return E('tr', {}, [
			E('td', {}, humanCounter(counter)),
			E('td', { 'class': 'qa-number qa-counter-value', 'title': String(counter.value) }, formatInteger(counter.value)),
			E('td', { 'class': 'qa-number' + (result && result.reset ? ' qa-state-warn' : '') }, rate)
		]);
	});
	var content, table, footer = '';

	if (!isAvailable(client)) {
		content = E('div', { 'class': 'qa-empty' }, _('This firmware does not provide this metric.'));
	}
	else if (!isParsed(client)) {
		content = E('div', { 'class': 'qa-empty qa-empty-unparsed' },
			_('The source exists, but its counter format was not recognized.'));
	}
	else if (!rows.length) {
		content = E('div', { 'class': 'qa-empty' }, _('No parsed counters were returned.'));
	}
	else {
		table = E('div', { 'class': 'qa-table-wrap qa-performance-table-wrap' }, E('table', {
			'class': 'table qa-diagnostic-table qa-performance-table'
		}, [
			E('thead', {}, E('tr', {}, [
				E('th', {}, _('Counter')),
				E('th', { 'class': 'qa-number' }, _('Cumulative')),
				E('th', { 'class': 'qa-number' }, _('Rate'))
			])),
			E('tbody', {}, rows)
		]));
		content = selection.rawFallback
			? E('div', {}, [
				E('div', { 'class': 'qa-parse-note' },
					_('No standard RX/TX, drop or error categories were identified. Showing parsed counters instead.')),
				table
			])
			: table;

		if (entries.length > MAX_COUNTERS_PER_CLIENT) {
			footer = E('div', { 'class': 'qa-meta qa-counter-limit' }, selection.rawFallback
				? _('Showing %d of %s parsed counters.').format(
					MAX_COUNTERS_PER_CLIENT, formatInteger(parsedCounterCount(client)) || String(entries.length))
				: _('Showing %d of %d relevant counters.').format(MAX_COUNTERS_PER_CLIENT, entries.length));
		}
	}

	return E('section', { 'class': 'qa-telemetry-client' }, [
		E('div', { 'class': 'qa-client-header' }, [
			E('h3', { 'class': 'qa-section-title' }, clientNames[name] || name),
			E('div', { 'class': 'qa-client-meta' }, [
				client.source && client.source !== 'unavailable'
					? E('span', { 'class': 'qa-meta qa-source' }, sourceText(client.source))
					: '',
				isAvailable(client)
					? E('span', { 'class': 'qa-meta qa-counter-count' }, parsedCountText(client))
					: ''
			])
		]),
		content,
		footer
	]);
}

function sampleTime(data) {
	var value = Number(data && data.sampled_at);
	return isFinite(value) && value > 0 ? Math.floor(value) : null;
}

function sampleLabel(data) {
	var value = sampleTime(data);
	if (!value)
		return _('Sample time unavailable');
	return _('Last sample: %s').format(new Date(value * 1000).toLocaleTimeString());
}

return view.extend({
	history: null,
	previous: null,

	load: function() {
		return callTelemetry().catch(function(error) {
			return { _rpc_error: error && error.message ? error.message : String(error) };
		});
	},

	calculateRates: function(data) {
		var currentTime = sampleTime(data);
		var currentUptime = numericCounter(data && data.uptime_seconds);
		var currentCounters = counterMap(data);
		var rates = {};
		var elapsed = this.previous && currentTime && this.previous.sampledAt
			? currentTime - this.previous.sampledAt
			: 0;
		var resetAll = this.previous && (
			(currentUptime !== null && this.previous.uptime !== null && currentUptime < this.previous.uptime) ||
			(currentTime && this.previous.sampledAt && currentTime <= this.previous.sampledAt)
		);
		if (resetAll) {
			Object.keys(currentCounters).forEach(function(key) {
				if (Object.prototype.hasOwnProperty.call(this.previous.counters, key))
					rates[key] = { reset: true };
			}, this);
		}
		else if (elapsed > 0) {
			Object.keys(currentCounters).forEach(function(key) {
				if (Object.prototype.hasOwnProperty.call(this.previous.counters, key))
					rates[key] = rateBetween(currentCounters[key], this.previous.counters[key], elapsed);
			}, this);
		}
		this.previous = { sampledAt: currentTime, uptime: currentUptime, counters: currentCounters };
		return rates;
	},

	pushHistory: function(data) {
		var ecm = data.ecm || {};
		var ipv4 = ecm.ipv4 || {};
		var ipv6 = ecm.ipv6 || {};
		var load = (data.core || {}).load || {};
		this.history.push({
			time: sampleTime(data),
			load: isAvailable(load) && isParsed(load) ? loadPercent(data) : null,
			ipv4: isAvailable(ipv4) ? numericCounter(ipv4.accelerated) : null,
			ipv6: isAvailable(ipv6) ? numericCounter(ipv6.accelerated) : null
		});
		if (this.history.length > MAX_SAMPLES)
			this.history.splice(0, this.history.length - MAX_SAMPLES);
	},

	drawHistory: function() {
		var loads = this.history.map(function(sample) { return sample.load; });
		var ipv4 = this.history.map(function(sample) { return sample.ipv4; });
		var ipv6 = this.history.map(function(sample) { return sample.ipv6; });
		var flowValues = ipv4.concat(ipv6).filter(function(value) { return value !== null && isFinite(value); });
		var maxFlows = flowValues.length
			? Math.max(1, Math.ceil(Math.max.apply(null, flowValues) * 1.1))
			: 1;
		drawChart('qa-performance-load-chart', [ loads ], 100);
		drawChart('qa-performance-flow-chart', [ ipv4, ipv6 ], maxFlows);
	},

	updateTelemetry: function(data, error) {
		data = data || {};
		var summary = document.getElementById('qa-performance-summary');
		var clientContent = document.getElementById('qa-performance-clients');
		var status = document.getElementById('qa-performance-status');
		var statusDetail = document.getElementById('qa-performance-status-detail');
		var dot = document.getElementById('qa-performance-dot');

		if (status) {
			status.textContent = error ? _('Telemetry unavailable') : sampleLabel(data);
			status.className = error ? 'qa-state-warn' : 'qa-state-ok';
		}
		if (dot)
			dot.className = 'qa-dot ' + (error ? 'qa-dot-warn' : 'qa-dot-on');

		if (error) {
			if (statusDetail)
				statusDetail.textContent = _('Unable to read performance telemetry. Showing the last successful sample.');
			return;
		}

		var rates = this.calculateRates(data);
		var core = data.core || {};
		var loadMetric = core.load || {};
		var load = isAvailable(loadMetric) && isParsed(loadMetric) ? loadPercent(data) : null;
		var loadEmpty = capabilityEmptyText(loadMetric, _('The load field was not recognized.'));
		var clock = clockText(core);
		var ecm = data.ecm || {};
		var ipv4 = ecm.ipv4 || {};
		var ipv6 = ecm.ipv6 || {};
		var clients = data.clients || {};
		var platform = data.platform || {};
		if (statusDetail)
			statusDetail.textContent = _('%s · %s front end').format(
				(platform.family || platform.soc || _('Unknown platform')).toUpperCase(),
				String(data.frontend || 'unknown').toUpperCase());

		if (summary)
			summary.replaceChildren(
				metricCard(_('NSS Core 0 load'), load === null ? null : load.toFixed(1) + '%',
					capabilityMeta(loadMetric), loadEmpty),
				metricCard(_('NSS clock'), clock, sourceText(core.clock_source || core.source)),
				metricCard(_('ECM connections'), isAvailable(ecm) ? formatInteger(ecm.connections) : null, sourceText(ecm.source)),
				metricCard(_('Total accelerated'), isAvailable(ecm) ? formatInteger(ecm.accelerated) : null, _('Current offloaded flows')),
				metricCard(_('IPv4 accelerated'), isAvailable(ipv4) ? formatInteger(ipv4.accelerated) : null,
					isAvailable(ipv4) ? _('TCP %s / UDP %s / other %s').format(formatInteger(ipv4.tcp), formatInteger(ipv4.udp), formatInteger(ipv4.non_ported)) : sourceText(ipv4.source)),
				metricCard(_('IPv6 accelerated'), isAvailable(ipv6) ? formatInteger(ipv6.accelerated) : null,
					isAvailable(ipv6) ? _('TCP %s / UDP %s / other %s').format(formatInteger(ipv6.tcp), formatInteger(ipv6.udp), formatInteger(ipv6.non_ported)) : sourceText(ipv6.source)),
				metricCard(_('Pending commands'), isAvailable(ecm) ? formatInteger(ecm.pending) : null, _('Acceleration and deceleration queue'))
			);

		if (clientContent) {
			var sections = clientOrder.filter(function(name) {
				return name !== 'pppoe' || isAvailable(clients.pppoe);
			}).map(function(name) {
				return clientSection(name, clients[name], rates);
			});
			clientContent.replaceChildren.apply(clientContent, sections);
		}

		setChartEmptyText('qa-performance-load-chart', loadEmpty);
		this.pushHistory(data);
		window.setTimeout(this.drawHistory.bind(this), 0);
	},

	render: function(data) {
		var self = this;
		addStyle();
		this.history = [];
		this.previous = null;

		poll.add(function() {
			return callTelemetry().then(function(fresh) {
				self.updateTelemetry(fresh, false);
			}).catch(function() {
				self.updateTelemetry(null, true);
			});
		}, POLL_SECONDS);

		var body = E('div', { 'class': rootClass() }, [
			E('h2', {}, _('NSS Performance')),
			E('p', {}, _('Live, read-only NSS and ECM performance telemetry. History stays in this browser tab and is cleared when the page is closed or refreshed.')),
			E('div', { 'class': 'qa-hero qa-performance-hero' }, [
				E('div', {}, [
					E('h2', {}, _('Live telemetry')),
					E('p', { 'id': 'qa-performance-status-detail' }, _('Waiting for telemetry…'))
				]),
				E('div', { 'class': 'qa-hero-value qa-sample-state' }, [
					E('span', { 'id': 'qa-performance-dot', 'class': 'qa-dot qa-dot-on' }),
					E('span', { 'id': 'qa-performance-status' }, _('Waiting for telemetry…'))
				])
			]),
			E('div', { 'id': 'qa-performance-summary', 'class': 'qa-grid qa-performance-summary' }),
			E('div', { 'class': 'qa-chart-grid' }, [
				chart(_('NSS Core 0 load history'), 'qa-performance-load-chart', [
					E('span', { 'class': 'qa-legend-a' }, _('% utilization'))
				]),
				chart(_('Accelerated-flow history'), 'qa-performance-flow-chart', [
					E('span', { 'class': 'qa-legend-a' }, _('IPv4')),
					E('span', { 'class': 'qa-legend-b' }, _('IPv6'))
				])
			]),
			E('h2', { 'class': 'qa-section-title' }, _('NSS client counters')),
			E('p', {}, _('Rates use the actual interval between adjacent router samples. A lower counter resets its baseline and never produces a negative rate.')),
			E('div', { 'id': 'qa-performance-clients' }),
			E('div', { 'class': 'qa-warning' }, _('Unavailable counters are firmware capabilities, not health failures. No telemetry history is written to the router.'))
		]);

		window.setTimeout(function() {
			if (data && data._rpc_error)
				self.updateTelemetry(null, true);
			else
				self.updateTelemetry(data, false);
		}, 0);
		return body;
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
