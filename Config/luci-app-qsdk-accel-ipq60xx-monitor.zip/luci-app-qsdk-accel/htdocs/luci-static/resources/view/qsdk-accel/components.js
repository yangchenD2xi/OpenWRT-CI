'use strict';
'require view';
'require rpc';

var callComponents = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'components',
	expect: { '': {} }
});

var componentInfo = {
	ecm: [ _('ECM'), _('Tracks connections and selects flows for acceleration.') ],
	nss_driver: [ _('NSS driver'), _('Host driver and statistics interface for the NSS firmware.') ],
	data_plane: [ _('NSS data plane'), _('Ethernet data-plane integration used by NSS interfaces.') ],
	ssdk: [ _('Switch SDK'), _('Qualcomm switch and packet-processing hardware driver.') ],
	crypto: [ _('Crypto engine'), _('Hardware-assisted cryptographic processing client.') ],
	bridge: [ _('Bridge manager'), _('Bridge traffic integration with the acceleration path.') ],
	vlan: [ _('VLAN manager'), _('VLAN interface and rule integration.') ],
	lag: [ _('Link aggregation'), _('Link-aggregation integration with the acceleration path.') ],
	pppoe: [ _('PPPoE'), _('PPPoE session acceleration client.') ],
	gre: [ _('GRE'), _('GRE tunnel acceleration client.') ],
	vxlan: [ _('VXLAN'), _('VXLAN tunnel acceleration manager.') ],
	map_t: [ _('MAP-T'), _('IPv4/IPv6 MAP-T translation acceleration client.') ],
	l2tpv2: [ _('L2TPv2'), _('L2TPv2 tunnel acceleration client.') ],
	pptp: [ _('PPTP'), _('PPTP tunnel acceleration client.') ],
	tun6rd: [ _('6rd'), _('IPv6 rapid-deployment tunnel acceleration client.') ],
	tunipip6: [ _('IP-in-IPv6'), _('IP-in-IPv6 tunnel acceleration client.') ],
	wifi_mesh: [ _('Wi-Fi mesh'), _('Wireless mesh acceleration manager.') ],
	netlink: [ _('NSS netlink'), _('Userspace messaging interface for NSS clients.') ]
};

var categoryNames = {
	core: _('Core stack'),
	engine: _('Engines'),
	manager: _('Network managers'),
	tunnel: _('Tunnel clients'),
	wireless: _('Wireless'),
	utility: _('Utilities')
};

function addStyle() {
	if (!document.querySelector('link[data-qsdk-accel]'))
		document.head.appendChild(E('link', {
			rel: 'stylesheet',
			href: L.resource('view/qsdk-accel/style.css'),
			'data-qsdk-accel': '1'
		}));
}

function isDarkTheme() {
	var media = String((L.env && L.env.media) || '').toLowerCase();
	var links = document.querySelectorAll('link[rel="stylesheet"]');
	var color, match, luminance;
	if (media.indexOf('bootstrap-dark') !== -1)
		return true;
	for (var i = 0; i < links.length; i++)
		if (String(links[i].href || '').toLowerCase().indexOf('/bootstrap-dark/') !== -1)
			return true;
	color = window.getComputedStyle(document.body).backgroundColor;
	match = color && color.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
	if (!match)
		return false;
	luminance = 0.2126 * +match[1] + 0.7152 * +match[2] + 0.0722 * +match[3];
	return luminance < 128;
}

function rootClass() {
	return 'qa-root ' + (isDarkTheme() ? 'qa-theme-dark' : 'qa-theme-light');
}

function formatBytes(value, available) {
	if (!available || value === '' || value === null || value === undefined || !/^\d+$/.test(String(value)))
		return _('Not available');
	value = +value;
	if (!value)
		return '0 B';
	if (value >= 1048576)
		return (value / 1048576).toFixed(1) + ' MB';
	return (value / 1024).toFixed(1) + ' KB';
}

function summaryCard(label, value, meta) {
	return E('div', { 'class': 'qa-card' }, [
		E('div', { 'class': 'qa-label' }, label),
		E('div', { 'class': 'qa-value' }, value),
		E('div', { 'class': 'qa-meta' }, meta)
	]);
}

function componentCard(item) {
	var info = componentInfo[item.id] || [ item.id, _('Detected acceleration component.') ];
	var state, stateClass;

	if (item.loaded && item.stats_available) {
		state = _('Loaded · telemetry available');
		stateClass = 'qa-state-ok';
	}
	else if (item.loaded) {
		state = _('Loaded');
		stateClass = 'qa-state-warn';
	}
	else {
		state = _('Not loaded');
		stateClass = 'qa-state-off';
	}

	return E('div', { 'class': 'qa-card qa-component' }, [
		E('div', { 'class': 'qa-component-title' }, [
			E('strong', {}, info[0]),
			E('span', { 'class': 'qa-component-state ' + stateClass }, state)
		]),
		E('div', { 'class': 'qa-component-module' }, item.module || '—'),
		E('div', { 'class': 'qa-component-desc' }, info[1])
	]);
}

return view.extend({
	load: function() {
		return callComponents();
	},

	render: function(data) {
		addStyle();
		data = data || {};
		var content;
		var clockHz = +data.clock_hz || 0;
		var clock = isFinite(clockHz) && clockHz > 0
			? (clockHz / 1000000).toFixed(clockHz % 1000000 ? 1 : 0) + ' MHz'
			: _('Not available');
		var clockMode = data.auto_scale === '1'
			? _('Automatic scaling enabled')
			: data.auto_scale === '0'
				? _('Fixed clock mode')
				: _('Clock scaling mode not exposed');
		var groups = {};
		(data.items || []).forEach(function(item) {
			(groups[item.category] || (groups[item.category] = [])).push(item);
		});

		var sections = [];
		Object.keys(categoryNames).forEach(function(category) {
			if (!groups[category] || !groups[category].length)
				return;
			sections.push(E('h3', { 'class': 'qa-section-title' }, categoryNames[category]));
			sections.push(E('div', { 'class': 'qa-component-grid' }, groups[category].map(componentCard)));
		});

		var cores = (data.cores || []).map(function(core) {
			return E('span', {
				'class': 'qa-core-pill ' + (core.booted ? 'qa-state-ok' : 'qa-state-off')
			}, _('Core %d: %s').format(core.id, core.booted ? _('booted') : _('not detected')));
		});

		var features = (data.stats_features || []).map(function(feature) {
			return E('span', { 'class': 'qa-tag' }, feature);
		});
		if (!features.length)
			features.push(E('span', { 'class': 'qa-tag' }, _('None detected')));

		content = [
			E('h2', {}, _('QSDK Acceleration Components')),
			E('p', {}, _('Detected NSS cores, kernel clients and telemetry interfaces. A loaded module can be healthy even when it has no dedicated statistics file.')),
			E('div', { 'class': 'qa-grid' }, [
				summaryCard(_('NSS firmware'), data.firmware || _('Not available'), _('Firmware running on the NSS cores')),
				summaryCard(_('NSS clock'), clock, clockMode),
				summaryCard(_('Core 0 extra PBUF'), formatBytes(data.extra_pbuf_core0, data.core0_available), _('Additional NSS packet-buffer memory')),
				summaryCard(_('Core 1 extra PBUF'), formatBytes(data.extra_pbuf_core1, data.core1_available), data.core1_available ? _('Additional NSS packet-buffer memory') : _('NSS Core 1 is not present on this platform'))
			]),
			E('div', { 'class': 'qa-core-row' }, cores)
		];
		Array.prototype.push.apply(content, sections);
		content.push(
			E('h3', { 'class': 'qa-section-title' }, _('Available NSS statistics')),
			E('div', {}, features)
		);

		return E('div', { 'class': rootClass() }, content);
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
