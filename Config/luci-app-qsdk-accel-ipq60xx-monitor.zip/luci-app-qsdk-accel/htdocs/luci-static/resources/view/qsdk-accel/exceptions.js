'use strict';
'require view';
'require rpc';
'require ui';
'require qsdk_accel.decimal as decimal';

var callExceptions = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'exceptions',
	expect: { '': {} }
});

function addStyle() {
	if (!document.querySelector('link[data-qsdk-accel]'))
		document.head.appendChild(E('link', {
			rel: 'stylesheet',
			href: L.resource('view/qsdk-accel/style.css'),
			'data-qsdk-accel': '1'
		}));
}

function isDarkTheme() {
	var media = String((L.env && L.env.media) || '').toLowerCase();
	var links = document.querySelectorAll('link[rel="stylesheet"]');
	var color, match, luminance;
	if (media.indexOf('bootstrap-dark') !== -1)
		return true;
	for (var i = 0; i < links.length; i++)
		if (String(links[i].href || '').toLowerCase().indexOf('/bootstrap-dark/') !== -1)
			return true;
	color = window.getComputedStyle(document.body).backgroundColor;
	match = color && color.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
	if (!match)
		return false;
	luminance = 0.2126 * +match[1] + 0.7152 * +match[2] + 0.0722 * +match[3];
	return luminance < 128;
}

function rootClass() {
	return 'qa-root ' + (isDarkTheme() ? 'qa-theme-dark' : 'qa-theme-light');
}

function humanize(value) {
	return String(value || _('Unknown reason'))
		.replace(/^exception[_ :.-]*/i, '')
		.replace(/[_-]+/g, ' ')
		.replace(/\b\w/g, function(letter) { return letter.toUpperCase(); });
}

function card(label, value, meta) {
	return E('div', { 'class': 'qa-card' }, [
		E('div', { 'class': 'qa-label' }, label),
		E('div', { 'class': 'qa-value' }, String(value)),
		E('div', { 'class': 'qa-meta' }, meta)
	]);
}

function exactValue(item) {
	if (item.value_exact !== undefined)
		return decimal.decimalText(item.value_exact);
	// Old numeric responses may already have lost precision; never invent it.
	var value = item.value;
	return typeof value === 'number' && value >= 0 && value <= 9007199254740991 && Math.floor(value) === value
		? String(value) : null;
}

function familySummary(family) {
	family = family || {};
	var modern = family.scanned_total !== undefined;
	var total = modern ? decimal.decimalText(family.scanned_total) : null;
	var valid = family.available && modern && family.parsed_count > 0 && total !== null;
	return {
		modern: modern,
		valid: valid,
		total: valid ? total : null,
		complete: valid && family.complete === true,
		value: valid ? decimal.formatInteger(total) : _('Unavailable'),
		meta: !family.available ? _('This firmware does not expose this exception counter file.')
			: !modern ? _('Legacy response: full total and precision are unavailable.')
			: !valid ? _('No valid exception counters were read.')
			: family.complete ? _('Complete source; showing %d of %d non-zero reasons.').format(family.returned_count, family.scanned_nonzero_count)
			: _('Partial scan; showing %d of %d observed non-zero reasons.').format(family.returned_count, family.scanned_nonzero_count)
	};
}

function reasonTable(title, family) {
	family = family || {};
	var items = family.items || [];
	var summary = familySummary(family);
	var rows = [];

	if (!family.available)
		return E('section', { 'class': 'qa-reason-section' }, [
			E('h3', { 'class': 'qa-section-title' }, title),
			E('div', { 'class': 'qa-empty' }, _('This firmware does not expose this exception counter file.'))
		]);

	var source = family.source && family.source !== 'unavailable'
		? E('div', { 'class': 'qa-meta' }, _('Counter source: %s').format(family.source))
		: '';

	if (!items.length)
		return E('section', { 'class': 'qa-reason-section' }, [
			E('h3', { 'class': 'qa-section-title' }, title),
			source,
			E('div', { 'class': 'qa-empty' }, summary.complete && summary.total === '0'
				? _('No non-zero exception counters were reported.') : summary.meta)
		]);

	items.forEach(function(item) {
		var value = exactValue(item);
		var share = decimal.percentage(value, summary.total);
		rows.push(E('tr', {}, [
			E('td', {}, [
				E('div', { 'class': 'qa-reason-name' }, humanize(item.label || item.id)),
				share === null ? '' : E('div', { 'class': 'qa-reason-bar' }, E('span', { style: 'width:' + share + '%' }))
			]),
			E('td', { 'class': 'qa-number' }, value === null ? _('Precision unavailable') : decimal.formatInteger(value)),
			E('td', { 'class': 'qa-number' }, share === null ? '—' : share === '0.0' && value !== '0' ? '<0.1%' : share + '%')
		]));
	});

	return E('section', { 'class': 'qa-reason-section' }, [
		E('h3', { 'class': 'qa-section-title' }, title),
		source,
		E('div', { 'class': 'qa-meta' }, summary.meta),
		E('div', { 'class': 'qa-table-wrap' }, E('table', { 'class': 'table qa-diagnostic-table' }, [
			E('thead', {}, E('tr', {}, [
				E('th', {}, _('Reason')),
				E('th', { 'class': 'qa-number' }, _('Count')),
				E('th', { 'class': 'qa-number' }, summary.complete ? _('Share of total') : _('Share of scanned sum'))
			])),
			E('tbody', {}, rows)
		]))
	]);
}

function dominant(data) {
	var items = ((data.ipv4 || {}).items || []).concat(((data.ipv6 || {}).items || []));
	if (!items.length || items.some(function(item) { return exactValue(item) === null; }))
		return { label: _('Unavailable'), value: null };
	items.sort(function(a, b) { return decimal.compareDecimal(exactValue(b), exactValue(a)); });
	return { label: humanize(items[0].label || items[0].id), value: exactValue(items[0]) };
}

function renderData(data) {
	data = data || {};
	var ipv4 = data.ipv4 || {};
	var ipv6 = data.ipv6 || {};
	var top = dominant(data);
	var v4 = familySummary(ipv4);
	var v6 = familySummary(ipv6);
	return [
		E('div', { 'class': 'qa-grid' }, [
			card(v4.complete ? _('IPv4 exception total') : _('IPv4 scanned sum'), v4.value, v4.meta),
			card(v6.complete ? _('IPv6 exception total') : _('IPv6 scanned sum'), v6.value, v6.meta),
			card(_('Largest displayed reason'), top.label, top.value === null ? _('No exact count available.') : _('%s occurrences').format(decimal.formatInteger(top.value))),
			card(_('Counter uptime'), formatUptime(data.uptime_seconds), _('Counters may reset when ECM or the device restarts'))
		]),
		reasonTable(_('IPv4 offload exceptions'), ipv4),
		reasonTable(_('IPv6 offload exceptions'), ipv6)
	];
}

function formatUptime(seconds) {
	seconds = +seconds || 0;
	var days = Math.floor(seconds / 86400);
	var hours = Math.floor((seconds % 86400) / 3600);
	return days ? _('%d days %d hours').format(days, hours) : _('%d hours').format(hours);
}

return view.extend({
	load: function() {
		return callExceptions();
	},

	render: function(data) {
		addStyle();
		var content = E('div', { 'class': 'qa-dynamic-content' }, renderData(data));
		return E('div', { 'class': rootClass() }, [
			E('h2', {}, _('Offload diagnostics')),
			E('p', {}, _('Inspect the ECM reasons that prevented flows from entering the hardware acceleration path.')),
			E('div', { 'class': 'qa-warning' }, _('These are cumulative diagnostic counters, not a list of current faults. Normal traffic can legitimately increase many of them.')),
			E('div', { 'class': 'qa-actions' }, E('button', {
				'class': 'btn cbi-button-action',
				'click': function(ev) {
					var button = ev.currentTarget;
					button.disabled = true;
					callExceptions().then(function(fresh) {
						content.replaceChildren.apply(content, renderData(fresh));
					}).catch(function() {
						ui.addNotification(null, E('p', {}, _('Unable to refresh exception counters. Showing the last successful result.')), 'error');
					}).finally(function() { button.disabled = false; });
				}
			}, _('Refresh counters'))),
			content
		]);
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
