'use strict';
'require view';
'require rpc';
'require poll';
'require ui';

var callStatus = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'status',
	expect: { '': {} }
});

function addStyle() {
	if (!document.querySelector('link[data-qsdk-accel]'))
		document.head.appendChild(E('link', {
			rel: 'stylesheet',
			href: L.resource('view/qsdk-accel/style.css'),
			'data-qsdk-accel': '1'
		}));
}

function isDarkTheme() {
	var media = String((L.env && L.env.media) || '').toLowerCase();
	var links = document.querySelectorAll('link[rel="stylesheet"]');
	var color, match, luminance;
	if (media.indexOf('bootstrap-dark') !== -1)
		return true;
	for (var i = 0; i < links.length; i++)
		if (String(links[i].href || '').toLowerCase().indexOf('/bootstrap-dark/') !== -1)
			return true;
	color = window.getComputedStyle(document.body).backgroundColor;
	match = color && color.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
	if (!match)
		return false;
	luminance = 0.2126 * +match[1] + 0.7152 * +match[2] + 0.0722 * +match[3];
	return luminance < 128;
}

function rootClass() {
	return 'qa-root ' + (isDarkTheme() ? 'qa-theme-dark' : 'qa-theme-light');
}

function formatMemory(kb) {
	if (!kb)
		return '0 MB';
	return (kb / 1024).toFixed(kb >= 102400 ? 0 : 1) + ' MB';
}

function formatUptime(seconds) {
	seconds = +seconds || 0;
	var days = Math.floor(seconds / 86400);
	var hours = Math.floor((seconds % 86400) / 3600);
	return days ? '%dd %dh'.format(days, hours) : '%dh'.format(hours);
}

function setText(id, value) {
	var node = document.getElementById(id);
	if (node)
		node.textContent = value;
}

function card(label, id, meta, metaId) {
	var metaAttrs = { 'class': 'qa-meta' };
	if (metaId)
		metaAttrs.id = metaId;
	return E('div', { 'class': 'qa-card' }, [
		E('div', { 'class': 'qa-label' }, label),
		E('div', { 'class': 'qa-value', 'id': id }, '0'),
		E('div', metaAttrs, meta)
	]);
}

function chart(title, id, legend) {
	return E('div', { 'class': 'qa-card qa-chart-card' }, [
		E('div', { 'class': 'qa-chart-header' }, [
			E('div', { 'class': 'qa-label' }, title),
			E('div', { 'class': 'qa-chart-legend' }, legend)
		]),
		E('canvas', {
			'id': id,
			'class': 'qa-chart',
			'width': '640',
			'height': '180',
			'role': 'img',
			'aria-label': title
		})
	]);
}

function drawChart(id, series, maxValue) {
	var canvas = document.getElementById(id);
	if (!canvas || !series.length)
		return;

	var context = canvas.getContext('2d');
	if (!context)
		return;

	var rect = canvas.getBoundingClientRect();
	var width = Math.max(240, Math.round(rect.width || canvas.clientWidth || 320));
	var height = Math.max(100, Math.round(rect.height || canvas.clientHeight || 144));
	var ratio = Math.max(1, window.devicePixelRatio || 1);
	var root = canvas.closest('.qa-root') || document.documentElement;
	var style = window.getComputedStyle(root);
	var gridColor = style.getPropertyValue('--qa-chart-grid').trim() || '#607080';
	var textColor = style.getPropertyValue('--qa-meta').trim() || '#82909b';
	var colors = [
		style.getPropertyValue('--qa-chart-a').trim() || '#1686c9',
		style.getPropertyValue('--qa-chart-b').trim() || '#7357c6'
	];
	var padding = { left: 38, right: 8, top: 8, bottom: 18 };
	var plotWidth = width - padding.left - padding.right;
	var plotHeight = height - padding.top - padding.bottom;
	var ceiling = Math.max(+maxValue || 0, 1);

	if (canvas.width !== Math.round(width * ratio) || canvas.height !== Math.round(height * ratio)) {
		canvas.width = Math.round(width * ratio);
		canvas.height = Math.round(height * ratio);
	}
	context.setTransform(ratio, 0, 0, ratio, 0, 0);
	context.clearRect(0, 0, width, height);
	context.font = '10px sans-serif';
	context.textAlign = 'right';
	context.textBaseline = 'middle';
	context.fillStyle = textColor;
	context.strokeStyle = gridColor;
	context.lineWidth = 1;

	for (var grid = 0; grid <= 4; grid++) {
		var y = padding.top + plotHeight * grid / 4;
		context.globalAlpha = grid === 4 ? 0.8 : 0.35;
		context.beginPath();
		context.moveTo(padding.left, y + 0.5);
		context.lineTo(width - padding.right, y + 0.5);
		context.stroke();
		context.globalAlpha = 1;
		context.fillText(String(Math.round(ceiling * (4 - grid) / 4)), padding.left - 6, y);
	}

	series.forEach(function(values, seriesIndex) {
		if (!values || !values.length)
			return;
		context.strokeStyle = colors[seriesIndex] || colors[0];
		context.fillStyle = context.strokeStyle;
		context.lineWidth = 2;
		context.lineCap = 'round';
		context.lineJoin = 'round';
		context.beginPath();
		values.forEach(function(value, index) {
			var x = values.length === 1
				? padding.left + plotWidth
				: padding.left + index * plotWidth / (values.length - 1);
			var y = padding.top + plotHeight - Math.min(ceiling, Math.max(0, +value || 0)) / ceiling * plotHeight;
			if (index === 0)
				context.moveTo(x, y);
			else
				context.lineTo(x, y);
		});
		context.stroke();

		var last = values.length - 1;
		var lastX = values.length === 1 ? padding.left + plotWidth : padding.left + last * plotWidth / Math.max(1, values.length - 1);
		var lastY = padding.top + plotHeight - Math.min(ceiling, Math.max(0, +values[last] || 0)) / ceiling * plotHeight;
		context.beginPath();
		context.arc(lastX, lastY, 2.8, 0, Math.PI * 2);
		context.fill();
	});
}

function healthLabel(state) {
	return {
		active: _('Acceleration active'),
		idle: _('Ready, waiting for eligible traffic'),
		degraded: _('Acceleration degraded'),
		inactive: _('ECM inactive')
	}[state] || _('Status unknown');
}

return view.extend({
	actionBusy: false,
	history: null,

	load: function() {
		return callStatus();
	},

	pushHistory: function(data) {
		if (!this.history)
			this.history = { ipv4: [], ipv6: [], slab: [] };
		this.history.ipv4.push(+(data.hw_offload_ipv4 || 0));
		this.history.ipv6.push(+(data.hw_offload_ipv6 || 0));
		this.history.slab.push(data.mem_total_kb ? (+data.sunreclaim_kb || 0) * 100 / data.mem_total_kb : 0);
		Object.keys(this.history).forEach(function(key) {
			if (this.history[key].length > 60)
				this.history[key].shift();
		}, this);
	},

	updateCharts: function() {
		if (!this.history)
			return;
		var maxFlows = Math.ceil(Math.max.apply(null, this.history.ipv4.concat(this.history.ipv6).concat([1])) * 1.1);
		drawChart('qa-flow-chart', [ this.history.ipv4, this.history.ipv6 ], maxFlows);
		drawChart('qa-slab-chart', [ this.history.slab ], 100);
	},

	updateStatus: function(data) {
		data = data || {};
		var state = data.offload_monitor_health || 'unknown';
		var hero = document.getElementById('qa-health');
		var dot = document.getElementById('qa-state-dot');
		var clockHz = +data.nss_clock_hz || 0;
		var clock = clockHz > 0 ? (clockHz / 1000000).toFixed(1) + ' MHz' : '未提供';
		var fw = data.wifi_firmware_name && data.wifi_firmware_name !== 'not-detected' ? data.wifi_firmware_name : (data.nss_firmware || '未识别');
		var hw4 = +data.hw_offload_ipv4 || 0;
		var hw6 = +data.hw_offload_ipv6 || 0;
		var sw4 = +data.sw_offload_ipv4 || 0;
		var sw6 = +data.sw_offload_ipv6 || 0;
		var ct = (+data.ct_ipv4 || 0) + (+data.ct_ipv6 || 0);

		if (hero)
			hero.className = 'qa-hero qa-health-' + state;
		setText('qa-state', {
			active: '硬件卸载正在工作',
			idle: '硬件卸载已启用，当前无加速连接',
			degraded: '硬件卸载配置需要检查',
			unknown: '连接统计接口不可用'
		}[state] || '状态未知');
		if (dot) dot.className = 'qa-dot qa-dot-' + state;

		var valid = !!data.ct_available;
		setText('qa-ipv4', valid ? hw4 : 'N/A');
		setText('qa-ipv4-meta', 'Linux HW_OFFLOAD · IPv4');
		setText('qa-ipv6', valid ? hw6 : 'N/A');
		setText('qa-ipv6-meta', 'Linux HW_OFFLOAD · IPv6');
		setText('qa-total', valid ? hw4 + hw6 : 'N/A');
		setText('qa-share', valid && ct ? ((hw4 + hw6) * 100 / ct).toFixed(1) + '%' : 'N/A');
		setText('qa-pending', valid ? sw4 + sw6 : 'N/A');
		setText('qa-connections', valid ? ct : 'N/A');
		setText('qa-sunreclaim', formatMemory(data.sunreclaim_kb));
		setText('qa-sunreclaim-meta', '不可回收内核内存');
		setText('qa-memory', formatMemory(data.mem_available_kb));

		setText('qa-nss-wifi-core', data.nss_wifi_core_booted ? '已启动' : '未检测到');
		setText('qa-ppe-device', data.ppe_device_present ? '已初始化' : '未检测到');
		setText('qa-flowtable', data.nft_hw_flowtable ? '已建立' : '未检测到');
		setText('qa-hw-enabled', data.hw_offload_config ? '已开启' : '未开启');
		setText('qa-sw-enabled', data.flow_offload_config ? '已开启' : '未开启');
		setText('qa-ecm', data.ecm_loaded ? '已检测到' : '未安装 / 不适用');
		setText('qa-firmware', fw);
		setText('qa-clock', clock);
		setText('qa-platform', (data.platform_family || 'unknown').toUpperCase());
		setText('qa-uptime', formatUptime(data.uptime_seconds));
		setText('qa-source', valid ? '/proc/net/nf_conntrack' : '不可读取');

		this.pushHistory(data);
		this.updateCharts();
	},

	render: function(data) {
		var self = this;
		addStyle();
		this.history = { ipv4: [], ipv6: [], slab: [] };

		poll.add(function() {
			return callStatus().then(function(fresh) { self.updateStatus(fresh); });
		}, 5);

		var tags = [];
		if (data.nss_wifi_core_booted) tags.push(E('span', { 'class': 'qa-tag' }, 'NSS Wi-Fi'));
		if (data.ppe_device_present) tags.push(E('span', { 'class': 'qa-tag' }, 'QCA PPE'));
		if (data.nft_hw_flowtable) tags.push(E('span', { 'class': 'qa-tag' }, 'nft HW flowtable'));
		if (!tags.length) tags.push(E('span', { 'class': 'qa-tag' }, '未检测到后端'));

		var body = E('div', { 'class': rootClass() }, [
			E('h2', {}, _('QSDK Acceleration')),
			E('p', {}, 'IPQ60XX · 只读监控 Linux 硬件卸载 / NSS Wi-Fi / PPE（不要求 ECM）'),
			E('div', { 'id': 'qa-health', 'class': 'qa-hero' }, [
				E('div', {}, [
					E('h2', {}, '硬件卸载健康状态'),
					E('p', {}, [ '已检测组件：' + ' ', E('span', {}, tags) ])
				]),
				E('div', { 'class': 'qa-hero-value' }, [
					E('span', { 'id': 'qa-state-dot', 'class': 'qa-dot' }),
					E('span', { 'id': 'qa-state' })
				])
			]),
			E('div', { 'class': 'qa-grid' }, [
				card('IPv4 硬件卸载连接', 'qa-ipv4', '', 'qa-ipv4-meta'),
				card('IPv6 硬件卸载连接', 'qa-ipv6', '', 'qa-ipv6-meta'),
				card('硬件卸载总数', 'qa-total', 'Linux HW_OFFLOAD 标记'),
				card('硬件卸载连接占比', 'qa-share', '占当前可读取 conntrack 连接的比例'),
				card('软件卸载连接', 'qa-pending', 'Linux OFFLOAD（不含硬件卸载）'),
				card('连接跟踪总数', 'qa-connections', '当前可读取的 IPv4/IPv6 连接'),
				card('SUnreclaim', 'qa-sunreclaim', '', 'qa-sunreclaim-meta'),
				card('可用内存', 'qa-memory', '内核报告的可用内存')
			]),
			E('div', { 'class': 'qa-chart-grid' }, [
				chart('硬件卸载连接历史（页面打开期间）', 'qa-flow-chart', [
					E('span', { 'class': 'qa-legend-a' }, 'IPv4 HW'),
					E('span', { 'class': 'qa-legend-b' }, 'IPv6 HW')
				]),
				chart(_('SUnreclaim history'), 'qa-slab-chart', [
					E('span', { 'class': 'qa-legend-a' }, _('% of memory'))
				])
			]),
			E('h3', { 'class': 'qa-section-title' }, '驱动与加速配置'),
			E('div', { 'class': 'qa-grid' }, [
				card('NSS Wi-Fi 固件 / 核心', 'qa-nss-wifi-core', '检查驱动和启动日志'),
				card('QCA PPE', 'qa-ppe-device', '有线硬件数据路径'),
				card('nftables 硬件 Flowtable', 'qa-flowtable', '需 flags offload'),
				card('防火墙硬件卸载开关', 'qa-hw-enabled', 'flow_offloading_hw'),
				card('防火墙 Flow Offload', 'qa-sw-enabled', 'flow_offloading'),
				card('传统 ECM', 'qa-ecm', '当前架构未必需要 ECM'),
				card('NSS Wi-Fi 固件文件', 'qa-firmware', '从内核日志识别'),
				card('NSS 时钟', 'qa-clock', '内核提供的时钟值'),
				card('平台', 'qa-platform', '设备树识别'),
				card('系统运行时间', 'qa-uptime', '开机至今'),
				card('硬件卸载统计来源', 'qa-source', '不等于 NSS 核心内部统计')
			]),
			E('div', { 'class': 'qa-warning' }, '本页 HW_OFFLOAD 表示 Linux 硬件卸载标记，并不代表流量全部经过 NSS 核心。连接数为 0 时请结合实际 WAN 流量检查。此版本只监控，不提供 ECM 控制。')
		]);

		window.setTimeout(function() { self.updateStatus(data); }, 0);
		return body;
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
