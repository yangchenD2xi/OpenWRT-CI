'use strict';
'require view';
'require rpc';
'require ui';

var callDiagnostics = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'diagnostics',
	expect: { '': {} }
});

var callStatus = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'status',
	expect: { '': {} }
});

var callComponents = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'components',
	expect: { '': {} }
});

var callExceptions = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'exceptions',
	expect: { '': {} }
});

var callHealth = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'healthcheck',
	expect: { '': {} }
});

var callTelemetry = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'telemetry',
	expect: { '': {} }
});

function addStyle() {
	if (!document.querySelector('link[data-qsdk-accel]'))
		document.head.appendChild(E('link', {
			rel: 'stylesheet',
			href: L.resource('view/qsdk-accel/style.css'),
			'data-qsdk-accel': '1'
		}));
}

function isDarkTheme() {
	var media = String((L.env && L.env.media) || '').toLowerCase();
	var links = document.querySelectorAll('link[rel="stylesheet"]');
	var color, match, luminance;

	if (media.indexOf('bootstrap-dark') !== -1)
		return true;

	for (var i = 0; i < links.length; i++)
		if (String(links[i].href || '').toLowerCase().indexOf('/bootstrap-dark/') !== -1)
			return true;

	color = window.getComputedStyle(document.body).backgroundColor;
	match = color && color.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
	if (!match)
		return false;

	luminance = 0.2126 * +match[1] + 0.7152 * +match[2] + 0.0722 * +match[3];
	return luminance < 128;
}

function rootClass() {
	return 'qa-root ' + (isDarkTheme() ? 'qa-theme-dark' : 'qa-theme-light');
}

function download(filename, text, type) {
	var url = URL.createObjectURL(new Blob([ text ], { type: type || 'text/plain;charset=utf-8' }));
	var link = E('a', { href: url, download: filename });
	document.body.appendChild(link);
	link.click();
	link.remove();
	window.setTimeout(function() { URL.revokeObjectURL(url); }, 1000);
}

function optionalResult(name, request) {
	return request().then(function(value) {
		return { name: name, value: value };
	}).catch(function(error) {
		return { name: name, error: error && error.message ? error.message : String(error) };
	});
}

return view.extend({
	load: function() {
		return callDiagnostics();
	},

	render: function(data) {
		addStyle();
		var report = E('textarea', {
			'class': 'qa-report',
			'readonly': 'readonly',
			'wrap': 'off'
		}, (data && data.report) || _('No diagnostic data returned.'));

		return E('div', { 'class': rootClass() }, [
			E('h2', {}, _('QSDK Acceleration Diagnostics')),
			E('p', {}, _('This report contains platform, ECM counter, memory and filtered kernel-log information. Review it before sharing because device model and firmware versions are included.')),
			E('div', { 'class': 'qa-actions' }, [
				E('button', {
					'class': 'btn cbi-button-action',
					'click': function() {
						callDiagnostics().then(function(fresh) {
							report.value = (fresh && fresh.report) || '';
						});
					}
				}, _('Refresh')),
				E('button', {
					'class': 'btn',
					'click': function() {
						if (navigator.clipboard)
							navigator.clipboard.writeText(report.value).then(function() {
								ui.addNotification(null, E('p', {}, _('Diagnostic report copied.')), 'info');
							});
						else {
							report.select();
							document.execCommand('copy');
						}
					}
				}, _('Copy report')),
				E('button', {
					'class': 'btn',
					'click': function() {
						download('qsdk-accel-diagnostics.txt', report.value);
					}
				}, _('Download report')),
				E('button', {
					'class': 'btn',
					'click': function(ev) {
						var button = ev.currentTarget;
						button.disabled = true;
						Promise.all([
							optionalResult('status', callStatus),
							optionalResult('components', callComponents),
							optionalResult('exceptions', callExceptions),
							optionalResult('healthcheck', callHealth),
							optionalResult('telemetry', callTelemetry),
							optionalResult('diagnostics', callDiagnostics)
						]).then(function(values) {
							var results = {};
							var errors = {};
							values.forEach(function(result) {
								if (result.error)
									errors[result.name] = result.error;
								else
									results[result.name] = result.value;
							});
							var payload = {
								generated_at: new Date().toISOString(),
								status: results.status || null,
								components: results.components || null,
								exceptions: results.exceptions || null,
								healthcheck: results.healthcheck || null,
								telemetry: results.telemetry || null,
								report: (results.diagnostics && results.diagnostics.report) || '',
								errors: errors
							};
							download('qsdk-accel-diagnostics.json', JSON.stringify(payload, null, 2), 'application/json;charset=utf-8');
						}).catch(function(error) {
							ui.addNotification(null, E('p', {}, error.message || _('Unable to export diagnostic data.')), 'error');
						}).then(function() {
							button.disabled = false;
						});
					}
				}, _('Download JSON'))
			]),
			report
		]);
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
