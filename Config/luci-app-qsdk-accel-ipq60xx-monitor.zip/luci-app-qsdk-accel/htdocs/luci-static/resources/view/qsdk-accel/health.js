'use strict';
'require view';
'require rpc';
'require ui';

var callHealth = rpc.declare({
	object: 'luci.qsdk-accel',
	method: 'healthcheck',
	expect: { '': {} }
});

var checkText = {
	rpc_backend: [ _('RPC backend'), _('The LuCI service endpoint is installed and executable.') ],
	ecm_module: [ _('ECM kernel module'), _('ECM must be loaded before connections can be accelerated.') ],
	ecm_debugfs: [ _('ECM telemetry'), _('Runtime counters must be exposed through debugfs.') ],
	frontend: [ _('Acceleration front end'), _('An NSS, PPE, SFE or SDX front end should be detected.') ],
	ecm_service: [ _('ECM service'), _('A supported ECM init service is needed for start and restart controls.') ],
	nss_driver: [ _('NSS driver telemetry'), _('NSS statistics should be available when NSS is the active front end.') ],
	nss_core0: [ _('NSS core 0'), _('The first NSS firmware core should have completed boot.') ],
	nss_core1: [ _('NSS core 1'), _('The second NSS firmware core should have completed boot.') ],
	nss_redirect: [ _('NSS redirect'), _('Redirect should normally be enabled for the NSS acceleration path.') ],
	wifi_nss: [ _('Wi-Fi NSS integration'), _('Detection is capability-based; absence can be normal when Wi-Fi offload is not installed.') ],
	accel_modes: [ _('NSS acceleration modes'), _('At least one IP acceleration mode should be enabled.') ],
	pending_queue: [ _('Pending command queue'), _('A persistently large queue can indicate a stalled acceleration engine.') ],
	active_flows: [ _('Active accelerated flows'), _('Zero is normal when there is no eligible traffic.') ],
	memory_available: [ _('Available memory'), _('Low available memory can destabilize networking services.') ],
	sunreclaim: [ _('Unreclaimable kernel slab'), _('A high share can indicate a kernel-side memory leak.') ],
	exception_stats: [ _('Exception telemetry'), _('Exception counters improve diagnosis but are optional on some builds.') ]
};

function addStyle() {
	if (!document.querySelector('link[data-qsdk-accel]'))
		document.head.appendChild(E('link', {
			rel: 'stylesheet',
			href: L.resource('view/qsdk-accel/style.css'),
			'data-qsdk-accel': '1'
		}));
}

function isDarkTheme() {
	var media = String((L.env && L.env.media) || '').toLowerCase();
	var links = document.querySelectorAll('link[rel="stylesheet"]');
	var color, match, luminance;
	if (media.indexOf('bootstrap-dark') !== -1)
		return true;
	for (var i = 0; i < links.length; i++)
		if (String(links[i].href || '').toLowerCase().indexOf('/bootstrap-dark/') !== -1)
			return true;
	color = window.getComputedStyle(document.body).backgroundColor;
	match = color && color.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
	if (!match)
		return false;
	luminance = 0.2126 * +match[1] + 0.7152 * +match[2] + 0.0722 * +match[3];
	return luminance < 128;
}

function rootClass() {
	return 'qa-root ' + (isDarkTheme() ? 'qa-theme-dark' : 'qa-theme-light');
}

function stateLabel(state) {
	return { pass: _('Pass'), warn: _('Warning'), fail: _('Failed'), info: _('Information') }[state] || _('Information');
}

function overallLabel(state) {
	return { pass: _('All critical checks passed'), warn: _('Attention recommended'), fail: _('Action required') }[state] || _('Check completed');
}

function summaryCard(label, value, state) {
	return E('div', { 'class': 'qa-card qa-summary-' + state }, [
		E('div', { 'class': 'qa-label' }, label),
		E('div', { 'class': 'qa-value' }, String(value || 0))
	]);
}

function renderResult(data) {
	data = data || {};
	var summary = data.summary || {};
	var overall = summary.overall || 'fail';
	var checks = data.checks || [];
	var rows = checks.map(function(check) {
		var text = checkText[check.id] || [ check.id, _('No additional guidance is available.') ];
		return E('div', { 'class': 'qa-check-row qa-check-' + check.state }, [
			E('div', { 'class': 'qa-check-state' }, stateLabel(check.state)),
			E('div', { 'class': 'qa-check-body' }, [
				E('strong', {}, text[0]),
				E('div', { 'class': 'qa-check-desc' }, text[1])
			]),
			E('code', { 'class': 'qa-check-value' }, String(check.value || 'n/a'))
		]);
	});

	return [
		E('div', { 'class': 'qa-hero qa-health-' + overall }, [
			E('div', {}, [
				E('h2', {}, _('Health-check result')),
				E('p', {}, _('Checks are based on the live kernel, ECM and NSS state.'))
			]),
			E('div', { 'class': 'qa-hero-value' }, [
				E('span', { 'class': 'qa-dot qa-dot-' + overall }),
				overallLabel(overall)
			])
		]),
		E('div', { 'class': 'qa-grid qa-summary-grid' }, [
			summaryCard(_('Passed'), summary.pass, 'pass'),
			summaryCard(_('Warnings'), summary.warn, 'warn'),
			summaryCard(_('Failed'), summary.fail, 'fail'),
			summaryCard(_('Informational'), summary.info, 'info')
		]),
		E('div', { 'class': 'qa-check-list' }, rows)
	];
}

return view.extend({
	load: function() {
		return callHealth();
	},

	render: function(data) {
		addStyle();
		var result = E('div', { 'class': 'qa-health-result' }, renderResult(data));
		return E('div', { 'class': rootClass() }, [
			E('h2', {}, _('One-click health check')),
			E('p', {}, _('Run a read-only inspection of the acceleration stack and receive targeted guidance.')),
			E('div', { 'class': 'qa-actions' }, E('button', {
				'class': 'btn cbi-button-action important',
				'click': function(ev) {
					var button = ev.currentTarget;
					button.disabled = true;
					button.classList.add('spinning');
					callHealth().then(function(fresh) {
						result.replaceChildren.apply(result, renderResult(fresh));
					}).catch(function(error) {
						ui.addNotification(null, E('p', {}, error.message || _('Health check failed to run.')), 'error');
					}).finally(function() {
						button.disabled = false;
						button.classList.remove('spinning');
					});
				}
			}, _('Run health check'))),
			result
		]);
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
