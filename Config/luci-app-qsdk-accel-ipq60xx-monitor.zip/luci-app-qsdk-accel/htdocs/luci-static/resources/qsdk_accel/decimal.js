'use strict';
'require baseclass';

function decimalText(value) {
	var text;
	if (value === null || value === undefined)
		return null;
	text = String(value);
	if (!/^\d+$/.test(text))
		return null;
	return text.replace(/^0+(?=\d)/, '');
}

function formatInteger(value) {
	var text = decimalText(value);
	return text === null ? null : text.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function compareDecimal(left, right) {
	left = decimalText(left);
	right = decimalText(right);
	if (left === null || right === null)
		return null;
	if (left.length !== right.length)
		return left.length < right.length ? -1 : 1;
	return left === right ? 0 : (left < right ? -1 : 1);
}

function subtractDecimal(left, right) {
	var result = '', borrow = 0, index, digit;
	left = decimalText(left);
	right = decimalText(right);
	if (left === null || right === null || compareDecimal(left, right) < 0)
		return null;
	right = right.padStart(left.length, '0');
	for (index = left.length - 1; index >= 0; index--) {
		digit = (+left.charAt(index)) - (+right.charAt(index)) - borrow;
		if (digit < 0) {
			digit += 10;
			borrow = 1;
		}
		else {
			borrow = 0;
		}
		result = String(digit) + result;
	}
	return result.replace(/^0+(?=\d)/, '');
}

function divideDecimal(value, divisor, precision) {
	var input, quotient = '', remainder = 0, index, digit, split, integer, fraction;
	value = decimalText(value);
	divisor = Math.floor(+divisor || 0);
	precision = Math.max(0, Math.floor(+precision || 0));
	if (value === null || divisor <= 0)
		return null;
	input = value + new Array(precision + 1).join('0');
	for (index = 0; index < input.length; index++) {
		remainder = remainder * 10 + (+input.charAt(index));
		digit = Math.floor(remainder / divisor);
		remainder %= divisor;
		quotient += String(digit);
	}
	quotient = quotient.replace(/^0+(?=\d)/, '');
	if (!precision)
		return formatInteger(quotient);
	quotient = quotient.padStart(precision + 1, '0');
	split = quotient.length - precision;
	integer = formatInteger(quotient.slice(0, split));
	fraction = quotient.slice(split).replace(/0+$/, '');
	return fraction ? integer + '.' + fraction : integer;
}

// Small multipliers keep each digit operation within exact Number range.
function multiplySmall(value, multiplier) {
	var result = '', carry = 0, digit;
	for (var i = value.length - 1; i >= 0; i--) {
		digit = (+value.charAt(i)) * multiplier + carry;
		result = String(digit % 10) + result;
		carry = Math.floor(digit / 10);
	}
	return decimalText(String(carry || '') + result);
}

// Exact floor to one decimal place; only the bounded 0..1000 result is numeric.
function percentage(value, total) {
	value = decimalText(value);
	total = decimalText(total);
	if (value === null || total === null || total === '0' || compareDecimal(value, total) > 0)
		return null;
	var numerator = decimalText(value + '000');
	var low = 0, high = 1000, middle;
	while (low < high) {
		middle = Math.floor((low + high + 1) / 2);
		if (compareDecimal(multiplySmall(total, middle), numerator) <= 0)
			low = middle;
		else
			high = middle - 1;
	}
	return (low / 10).toFixed(1);
}

return baseclass.extend({
	decimalText: decimalText,
	formatInteger: formatInteger,
	compareDecimal: compareDecimal,
	subtractDecimal: subtractDecimal,
	divideDecimal: divideDecimal,
	percentage: percentage
});
